# prework-study-guide
This is where pre-work for Rutgers coding Bootcamp will be stored
